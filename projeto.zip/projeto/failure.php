<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Falha no Pagamento</title>
</head>
<body>
    <h1>❌ Pagamento Falhou</h1>
    <p><?= htmlspecialchars($_GET['msg'] ?? 'Tente novamente.') ?></p>
</body>
</html>