

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Currículo</title>
    <style>
        body{
            padding: 5rem;
            font-size: 1rem;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
        form{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            border: 1px solid #000;
            padding: 2rem;
            margin: 0 auto;
            width: max-content;
            gap: 2rem;
        }
        label{
            font-weight: 600;
            display: block;
            margin-bottom: 5px;
        }
        input{
            all:unset;
            border: 1px solid #000;
            padding: .5rem;
            margin-bottom: 10px;
        }
        input:focus{
            border: 2px solid #000;
        }
        .box:nth-child(1){
            grid-column: span 2;
        }
        textarea{
            font-size: 1rem;
            padding: .5rem;
            resize: none;
            width: 100%;
            height: 250px;
            grid-column: span 2;
        }
        input[type="submit"]{
            text-align: center;
            width: 100%;
            background: rgba(0, 0, 0, .5);
            color: white;
            font-weight: 600;
            grid-column: span 2;
        }
        .box:nth-child(6){
            grid-column: span 2;
        }
        input[type="file"]{
            width: 100%;
        }
    </style>
</head>
<body>
    <h1 style="text-align: center;">Seu Currículo</h1>

    <form action="receber.php" method="post">

        <div class="box">
            <input type="file" name="foto" id="foto" accept="image/*">
        </div>

        <div class="box">
            <label for="nomeCompleto">Nome completo</label>
            <input type="text" name="nome-completo" id="nomeCompleto">
        </div>

        <div class="box">
            <label for="telefone">Telefone</label>
            <input type="tel" name="telefone" id="telefone">
        </div>

        <div class="box">
            <label for="endereco">Endereço</label>
            <input type="text" name="endereco" id="endereco">
        </div>

        <div class="box">
            <label for="cargo">Cargo desejado</label>
            <input type="text" name="cargo" id="cargo">
        </div>

        <div class="box">
            <label for="habilidade">Habilidades</label>
            <textarea name="habilidade" id="habilidade"></textarea>
        </div>

        <input type="submit" name="enviar" id="enviar" value="Enviar">

        
    </form>

</body>
</html>