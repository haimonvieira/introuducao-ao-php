<?php

$nome = $_POST['nome-completo'];
$endereco = $_POST['endereco'];
$telefone = $_POST['telefone'];
$habilidades = $_POST['habilidade'];
$foto = $_POST['foto'];
$cargo = $_POST['cargo'];

?>



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seu Currículo</title>
    <style>
        body{
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            padding: 5rem;
            font-size: 1rem;
        }
        img{
            grid-column: span 2;
            width: 200px;
        }
        .box{
            margin: 0 auto;
            max-width: 50%;
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            border: 1px solid #000;
            padding: 2rem;
        }
    </style>
</head>
<body>

    <div class="box">

        <!-- <img src="https://placehold.co/200?text=Foto&font=roboto" alt=""> -->
        <img src="../aula03/<?= $foto?>" alt="">
        <p><strong>Nome: </strong> <?= $nome?></p>
        <p><strong>Telefone: </strong><?= $telefone?></p>
        <p><strong>Endereço: </strong><?= $endereco?></p>
        <p><strong>Habilidades: </strong><?= $habilidades?></p>
        <p><strong>Cargo desejado: </strong> <?= $cargo?></p>
        
    </div>

    <a href="index.php">Voltar</a>

    
</body>
</html>