<?php
$host = 'localhost';
$database = 'agenda';
$user = 'root';
$pass = '';

try{

    $pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $user, $pass);
}catch (PDOException $e){
    echo "Erro na conexão: " . $e->getMessage();
}

?>