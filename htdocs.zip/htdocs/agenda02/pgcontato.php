<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Contato</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">

</head>

<body>

    <?php include('menu.php'); ?>

    <div class="container">
        <h1>Gerenciamento de Contatos</h1>

        <!-- Botao acionar modal -->
        <!-- 'data-bs-target' é quem o botao ira acionar, no caso, 'modalAdicionar'-->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalAdicionar">
            + Adicionar Contato
        </button>

        <!-- Modal ADICIONAR inicio-->
        <div class="modal fade" id="modalAdicionar" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Cadastro de Contato</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="opcontato.php?acao=cadastrar" method="post">
                            <div class="mb-3">
                                <label class="form-label">Nome</label>
                                <input type="text" class="form-control" name="nome">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">E-mail</label>
                                <input type="text" class="form-control" name="email">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Telefone</label>
                                <input type="text" class="form-control" name="telefone">
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar Contato</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal ADICIONAR fim-->

        <div class="mt-5">
            <h4>Lista de Contatos</h4>
            <table class="table table-bordered table-dark text-center table-striped-columns table-hover">

                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Nome</th>
                        <th>E-mail</th>
                        <th>Telefone</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>
                    <?php

                    //Selecionando os registros de 'contatos'
                    $lista = $pdo->query("select * from contatos order by nome");

                    //Para cada registro existente, criar uma linha para ele
                    //com os dados do BD
                    while ($linha = $lista->fetch()) { ?>

                        <tr>
                            <td><?= $linha['id'] ?></td>
                            <td><?= $linha['nome'] ?></td>
                            <td><?= $linha['email'] ?></td>
                            <td><?= $linha['telefone'] ?></td>
                            <td>

                                <!-- Botao acionar modal -->
                                <!-- 'data-bs-target' é quem o botao ira acionar, no caso, 'modalAdicionar'-->
                                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalEditar<?= $linha['id'] ?>">
                                    Editar
                                </button>

                                <!-- Modal EDITAR inicio-->
                                <div class="modal fade" id="modalEditar<?= $linha['id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Edição de Contato</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body text-start">
                                                <form action="opcontato.php?acao=editar&id=<?= $linha['id'] ?>" method="post">
                                                    <div class="mb-3">
                                                        <label class="form-label">Nome</label>
                                                        <input type="text" class="form-control" name="nome" value="<?= $linha['nome'] ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">E-mail</label>
                                                        <input type="text" class="form-control" name="email" value="<?= $linha['email'] ?>">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Telefone</label>
                                                        <input type="text" class="form-control" name="telefone" value="<?= $linha['telefone'] ?>">
                                                    </div>

                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                <button type="submit" class="btn btn-primary">Salvar Contato</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Modal EDITAR fim-->



                                <!-- Botao acionar modal -->
                                <!-- 'data-bs-target' é quem o botao ira acionar, no caso, 'modalAdicionar'-->
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalExcluir<?= $linha['id']?>">
                                    Excluir
                                </button>

                                <!-- Modal EXCLUIR inicio-->
                                <div class="modal fade" id="modalExcluir<?= $linha['id']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Excluir Contato</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Você tem certeza que deseja excluir?</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                                <a href="opcontato.php?acao=excluir&id=<?= $linha['id'] ?>" class="btn btn-danger">Excluir</a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Modal EXCLUIR fim-->

                                
                            </td>
                        </tr>


                    <?php
                    }

                    ?>
                </tbody>

            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>


</body>

</html>