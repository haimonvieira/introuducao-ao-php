<?php

include('conexao.php');


//Verificando se a requisição é um POST para obter os valores do input
if ($_POST) {
    $razao = $_POST['razao'];
    $fantasia = $_POST['fantasia'];
    $endereco = $_POST['endereco'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
}

//Caso haja requisição GET para 'acao' 
if (isset($_GET['acao'])) {

    //Verifica se a requisicao é para 'cadastrar'
    if ($_GET['acao'] === 'cadastrar') {

        $query = 'insert into fornecedores (razao, fantasia, endereco, email, telefone) values (?, ?, ?, ?, ?)';

        $insert = $pdo->prepare($query);
        $insert->bindValue(1, $razao);
        $insert->bindValue(2, $fantasia);
        $insert->bindValue(3, $endereco);
        $insert->bindValue(4, $email);
        $insert->bindValue(5, $telefone);
        $insert->execute();
    }

    //Verifica se a requisicao é para 'editar' e obtem o 'id'
    if ($_GET['acao'] === 'editar') {
        $id = $_GET['id'];

        $query = 'update fornecedores set razao = ?, fantasia = ?, endereco = ?, email = ?, telefone = ? where id = ?';

        $update = $pdo->prepare($query);
        $update->bindValue(1, $razao);
        $update->bindValue(2, $fantasia);
        $update->bindValue(3, $endereco);
        $update->bindValue(4, $email);
        $update->bindValue(5, $telefone);
        $update->bindValue(6, $id);
        $update->execute();
    }

    //Verifica se a requisicao é para 'excluir' e obtem o 'id'
    if ($_GET['acao'] === 'excluir') {

        $id = $_GET['id'];
        $query = 'delete from fornecedores where id = ?';
        $delete = $pdo->prepare($query);
        $delete->bindValue(1, $id);
        $delete->execute();
    }

    header("Location:pgfornecedor.php");
}
