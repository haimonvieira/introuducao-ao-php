<?php

include('conexao.php');



if ($_POST) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
}

if (isset($_GET['acao'])) {


    if ($_GET['acao'] === 'cadastrar') {

        $query = 'insert into contatos (nome, email, telefone) values (?, ?, ?)';

        $insert = $pdo->prepare($query);
        $insert->bindValue(1, $nome);
        $insert->bindValue(2, $email);
        $insert->bindValue(3, $telefone);
        $insert->execute();
    }

    if ($_GET['acao'] === 'editar') {
        $id = $_GET['id'];

        $query = 'update contatos set nome = ?, email = ?, telefone = ? where id = ?';

        $update = $pdo->prepare($query);
        $update->bindValue(1, $nome);
        $update->bindValue(2, $email);
        $update->bindValue(3, $telefone);
        $update->bindValue(4, $id);
        $update->execute();
    }

    if ($_GET['acao'] === 'excluir') {

        $id = $_GET['id'];
        $query = 'delete from contatos where id = ?';
        $delete = $pdo->prepare($query);
        $delete->bindValue(1, $id);
        $delete->execute();
    }

    header("Location:pgcontato.php");
}
