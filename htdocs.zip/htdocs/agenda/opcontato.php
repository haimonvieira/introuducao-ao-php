<?php
// O include pega o script e executa ele primeiro
include('conexao.php');

//Verificar se metodo for POST
if($_POST){
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
}

    if(isset($_GET['acao']) ){

        if($_GET['acao'] === 'cadastrar'){

       

            $sql = "insert into contatos (nome, email, telefone) values
            (?, ?, ?)";
            //Tratamento de dados antes da inserção
            $insert = $pdo->prepare($sql);

            //Tratando os dados para serem inseridos no campo certo
            $insert->bindValue(1, $nome);
            $insert->bindValue(2, $email);
            $insert->bindValue(3, $telefone);

            $insert->execute();
            //Voltar para a pagina inicial
            header("Location:index.php");
        } 

    
        if($_GET['acao'] === 'excluir'){
            $id = $_GET['id'];
            $sql = 'delete from contatos where id = ?';
            $delete = $pdo->prepare($sql);
            $delete->bindValue(1, $id);
            $delete->execute();
            header("Location:index.php");

        }

        if($_GET['acao'] === 'editar'){
            $id = $_GET['id'];
            $sql = 'update contatos set nome = ?, email = ?, telefone = ? where id = ?';
            $edit = $pdo->prepare($sql);
            $edit->bindValue(1, $nome);
            $edit->bindValue(2, $email);
            $edit->bindValue(3, $telefone);
            $edit->bindValue(4, $id);
            $edit->execute();
            header("Location:index.php");

        }

    }


?>