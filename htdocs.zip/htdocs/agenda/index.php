<?php
include('conexao.php');
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>
    <div class="container">
        
        <h1>Agenda de Contatos</h1>
        <a href="adicionar.php" class="btn btn-success mb-3">Adicionar contatos</a>

        <table class="table table-bordered table-dark table-hover">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Telefone</th>
                    <th>Ações</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    $lista = $pdo->query('select * from contatos order by nome');

                    while($linha = $lista->fetch()){
                    
                ?>
                    <tr>
                        <td><?php echo $linha['id'];?></td>
                        <td><?php echo $linha['nome'];?></td>
                        <td><?php echo $linha['email'];?></td>
                        <td><?php echo $linha['telefone'];?></td>
                        <td>
                            <a href="editar.php?id=<?= $linha['id']?>" class="btn btn-warning">Editar</a>
                            <a href="opcontato.php?acao=excluir&id=<?php echo $linha['id'];?>" class="btn btn-danger" onclick="return confirm('Tem certeza? A ação não poderá ser desfeita.')">Excluir</a>
                        </td>
                    </tr>
                <?php }?>
            </tbody>
        </table>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
  </body>
</html>