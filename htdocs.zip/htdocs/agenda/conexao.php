<?php
// Conexão com servidor local
$host = 'localhost';
$db = 'agenda';
$user = 'root';
$pass = '';

try{

    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);

}catch(PDOException $e){
    echo ("Houve um erro na conexão: " . $e->getMessage());
}

?>