<?php

//Variaveis do tipo Array
$carros = ['Civic G10', 'Amarok', 'Tiggo 7 Pro'];

//O 'count' le o tamanho do array
// for($i = 0; $i < count($compras); $i++){
//     echo $compras[$i]. "<br>";
// }

//O 'var_dump' vai trazer informações para depuração como o tipo e a quantidade de elementos
var_dump($carros);

//Em vez de posições usando os numeros, é utilizado o apelido para aquela posição
$carro = [
    "modelo" => "Civic G10",
    "cor" => "Cinza",
    "marca" => "Honda",
    "ano" => 2025
];

var_dump($carro);

$estoque = [
    ["modelo" => "Civic G10", "cor" => "Cinza", "marca" => "Honda", "ano" => 2025, "foto" => "civic.png"],
    ["modelo" => "Amarok", "cor" => "Branco", "marca" => "Volkswagen", "ano" => 2019, "foto" => "amarok.png"],
    ["modelo" => "Tiggo 7 Pro", "cor" => "Branco", "marca" => "Caoacherry", "ano" => 2024, "foto" => "tiggo.jpg"]
];
echo '<br><br><br>';
var_dump($estoque);

echo '<br><br><br>';

//Dizendo para o 'estoque' que cada Array nele se chama 'item'
foreach($estoque as $item){
    echo "<strong>Modelo: </strong>".$item['modelo']. " - <strong>Cor: </strong>".
    $item['cor']. " - " . "<strong>Marca: </strong>". $item['marca']. " - " . "<strong>Ano: </strong>". $item['ano'] . " - " . "<strong>Foto: </strong>" .
     "<img src='".$item['foto']."'>" . "<br>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 03</title>
    <style>
        body{
            background: black;
            color: white;
        }
        img{
            width: 400px;
            border-radius: 8px;
        }
    </style>
</head>
<body>

    
</body>
</html>