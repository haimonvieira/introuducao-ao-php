<?php

$dentista = $_POST['dentista'];
$servicos = $_POST['servicos'];
$data = date("d/m/Y", strtotime($_POST['data']));
$horario = $_POST['hora'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1 style="text-align: center;">Sua Consulta</h1>
    <div class="consulta">
        <p><strong>Dentista: </strong><?= $dentista?></p>
        <p><strong>Serviço(s):</strong>
        <ul>
            <?php
            
                foreach($servicos as $servico){

                    if($servico == NULL){
                        echo "Sem serviços.";
                    }else{
                        echo "<li>" . htmlspecialchars($servico) . "</li>";
                    }
                }

            ?>
            </ul>
        </p>
        <p><strong>Data da Consulta</strong>
            <ul>
                <li><strong>Data: </strong><?= $data?></li>
                <li><strong>Horário: </strong><?= $horario?></li>
            </ul>
        </p>

    </div>

    <a href="index.php">Voltar ao Agendamento</a>


    
</body>
</html>