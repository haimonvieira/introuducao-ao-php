<!-- 
Agendamento Odontologico

-Nome cliente

Dentistas
- Álvaro da Silva
- Silvia Martins
- Lucio Otavio

Servicos
- Limpeza
- Clareamento
- Ortodontia
- Protse
-Canal

Data e hora(time) da consulta
-->

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SorriDente</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1>Bem vindo(a) a SorriDente!</h1>
    <p>Onde seu sorriso tem brilho!</p>


    <h2>Agende sua consulta agora! Preencha o formulário abaixo:</h2>

    <form action="receber.php" method="post">

        <div class="box">
            <label for="dentista">Conheça nossos dentistas</label>
            <select name="dentista" id="dentista">
                <option value="Álvaro da Silva">Álvaro da Silva</option>
                <option value="Silvia Martins">Silvia Martins</option>
                <option value="Lúcio Otavio">Lúcio Otavio</option>
            </select>
        </div>

        
        <div class="box">
            <label>Escolha o serviço</label>
            <input id="limpeza" type="checkbox" name="servicos[]" value="Limpeza">
            <label for="limpeza">Limpeza</label>
            <input id="clareamento" type="checkbox" name="servicos[]" value="Clareamento">
            <label for="clareamento">Clareamento</label>
            <input id="ortodontia" type="checkbox" name="servicos[]" value="Ortodontia">
            <label for="ortodontia">Ortodontia</label>
            <input id="protese" type="checkbox" name="servicos[]" value="Protese">
            <label for="protese">Protese</label>
            <input id="canal" type="checkbox" name="servicos[]" value="Canal">
            <label for="canal">Canal</label>

        </div>

        
        <div class="box">
            <label for="">Escolha a data da sua consulta</label>
            <input type="date" name="data">
            <input type="time" name="hora">
        </div>

        <input type="submit" value="Enviar">

    </form>
    
</body>
</html>