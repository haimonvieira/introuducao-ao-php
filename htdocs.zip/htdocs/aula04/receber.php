<?php

$nome = $_POST['nome'];
$genero = $_POST['genero'];
$servicos = $_POST['servicos'];
$estado = strtoupper($_POST['estado']);
$dataDeNascimento = $_POST['nascimento'];

$formatarData = date('d/m/Y', strtotime($dataDeNascimento));

?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preferências</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

    <h1>Preferências</h1>

    <p><strong>Nome: </strong><?= $nome?></p>
    <p><strong>Gênero: </strong><?= $genero?></p>
    <p><strong>Serviços Assinados: </strong>
        <ul>
            <?php

                foreach($servicos as $servico){
                    echo "<li>" . htmlspecialchars($servico) . "</li>";
                }
            ?>
        </ul>
    </p>
    <p><strong>Estado: </strong><?= $estado?></p>
    <p><strong>Data de Nascimento: </strong><?= $formatarData?></p>




    
</body>
</html>