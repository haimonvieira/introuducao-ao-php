

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 04</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>

    <h1 style="text-align: center; color: white;">Cadastro de Prefrências</h1>

    <form action="receber.php" method="post">

        <label for="nome">Nome</label>
        <input type="text" name="nome">

        <label for="genero">Gênero</label>
        <div class="grupo">
            <input type="radio" name="genero" value="masculino">Masculino
            <input type="radio" name="genero" value="femenino">Femenino
        </div>

        <label>Serviços Assinados</label>
        <div class="grupo">
            <input type="checkbox" name="servicos[]" value="Netflix">Netflix
            <input type="checkbox" name="servicos[]" value="Prime Video">Prime Video
            <input type="checkbox" name="servicos[]" value="Disney+">Disney+
            <input type="checkbox" name="servicos[]" value="Max (HBO)">Max (HBO)
        </div>

        <label>Estado</label>
        <select name="estado" id="estado">
            <option value="sp">sp</option>
            <option value="rj">rj</option>
            <option value="mg">mg</option>
            <option value="pr">pr</option>
        </select>

        <label>Data de Nascimento</label>
        <input type="date" name="nascimento">

        <input type="submit" value="Enviar">

    </form>
    
</body>
</html>