<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Pagar com Mercado Pago</title>
    <style>
        body { 
            font-family: Arial; 
            text-align: center; 
            padding: 50px; 
            margin: 0 auto;
        }
        .opcao { margin-bottom: 30px; }
        input, button { padding: 10px; margin-top: 10px; }
        button { background-color: #0096CF; color: white; border: none; cursor: pointer; border-radius: 5px; }

        
        #form-checkout {
        display: flex;
        flex-direction: column;
        max-width: 600px;
        }

        .container {
        height: 18px;
        display: inline-block;
        border: 1px solid rgb(118, 118, 118);
        border-radius: 2px;
        padding: 1px 2px;
        }
  
    </style>
</head>
<body>

<h1>Escolha a forma de pagamento</h1>

<div class="opcao">
    <h2>Pix</h2>
    <form action="payment.php" method="POST">
        <input type="hidden" name="tipo_pagamento" value="pix">
        <button type="submit">Pagar com Pix</button>
    </form>
</div>

<div class="opcao">

  <form id="form-checkout">
    <div id="form-checkout__cardNumber" class="container"></div>
    <div id="form-checkout__expirationDate" class="container"></div>
    <div id="form-checkout__securityCode" class="container"></div>
    <input type="text" id="form-checkout__cardholderName" />
    <select id="form-checkout__issuer"></select>
    <select id="form-checkout__installments"></select>
    <select id="form-checkout__identificationType"></select>
    <input type="text" id="form-checkout__identificationNumber" />
    <input type="email" id="form-checkout__cardholderEmail" />

    <button type="submit" id="form-checkout__submit">Pagar</button>
    <progress value="0" class="progress-bar">Carregando...</progress>
  </form>

    
</div>

<!-- SDK do Mercado Pago -->
<script src="https://sdk.mercadopago.com/js/v2"></script> 
<script>

    
    const publicKey = "TEST-4e62d963-2137-4356-b6bd-13efbe52add9";
    const accesToken =
  "TEST-8327064300769480-060212-379fa5056a643c425cbc6dc0f365e789-72839587";

const mp = new MercadoPago(publicKey, {
  locale: "pt-BR",
});

function carregarCardForm() {

  const payButton = document.getElementById("form-checkout__submit");
  const validationErrorMessages = document.getElementById(
    "validation-error-messages"
  );

  const cardForm = mp.cardForm({
    amount: "100.5",
    iframe: true,
    form: {
      id: "form-checkout",
      cardNumber: {
        id: "form-checkout__cardNumber",
        placeholder: "Número do cartão",
      },
      expirationDate: {
        id: "form-checkout__expirationDate",
        placeholder: "MM/YY",
      },
      securityCode: {
        id: "form-checkout__securityCode",
        placeholder: "Código de segurança",
      },
      cardholderName: {
        id: "form-checkout__cardholderName",
        placeholder: "Titular do cartão",
      },
      issuer: {
        id: "form-checkout__issuer",
        placeholder: "Banco emissor",
      },
      installments: {
        id: "form-checkout__installments",
        placeholder: "Parcelas",
      },
      identificationType: {
        id: "form-checkout__identificationType",
        placeholder: "Tipo de documento",
      },
      identificationNumber: {
        id: "form-checkout__identificationNumber",
        placeholder: "Número do documento",
      },
      cardholderEmail: {
        id: "form-checkout__cardholderEmail",
        placeholder: "E-mail",
      },
    },
    callbacks: {
      onFormMounted: (error) => {
        if (error) return console.warn("Form Mounted handling error: ", error);
        console.log("Form mounted");
      },
      onSubmit: (event) => {
        event.preventDefault();

        const {
          paymentMethodId: payment_method_id,
          issuerId: issuer_id,
          cardholderEmail: email,
          amount,
          token,
          installments,
          identificationNumber,
          identificationType,
        } = cardForm.getCardFormData();

        fetch("payment.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            token,
            issuer_id,
            payment_method_id,
            transaction_amount: Number(amount),
            installments: Number(installments),
            description: "Descrição do produto",
            payer: {
              email,
              identification: {
                type: identificationType,
                number: identificationNumber,
              },
            },
          }),
        })
          .then((response) => {
            console.log(response.json());
            return response.json();
          })
          .then((result) => {
            if (!result.hasOwnProperty("error_message")) {
              document.getElementById("success-response").style.display =
                "block";
              document.getElementById("payment-id").innerText = result.id;
              document.getElementById("payment-status").innerText =
                result.status;
              document.getElementById("payment-detail").innerText =
                result.detail;
            } else {
              document.getElementById("error-message").textContent =
                result.error_message;
              document.getElementById("fail-response").style.display = "block";
            }
          })
          .catch((error) => {
            alert("Unexpected error\n" + JSON.stringify(error));
          });
      },
      onFetching: (resource) => {
        console.log("Fetching resource: ", resource);
        payButton.setAttribute('disabled', true);

        // Animate progress bar
        const progressBar = document.querySelector(".progress-bar");
        progressBar.removeAttribute("value");

        return () => {
          progressBar.setAttribute("value", "0");
          payButton.removeAttribute('disabled');
        };
      },
    },
  });
}

document.addEventListener("DOMContentLoaded", () => {
  carregarCardForm();
});

</script>

</body>
</html>