<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Sucesso!</title>
</head>
<body>
    <h1>✅ Pagamento Aprovado!</h1>
    <p>Obrigado por sua compra.</p>
</body>
</html>