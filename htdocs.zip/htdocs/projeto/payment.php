<?php

$access_token = 'TEST-8327064300769480-060212-379fa5056a643c425cbc6dc0f365e789-72839587';

$json = file_get_contents('php://input');
$dados = json_decode($json); //Objeto com os dados a ser enviado
var_dump($dados);


if( isset($dados->token)){

    $token = $dados->token;
        if (!$token) {
            die("Erro: Token do cartão não foi fornecido.");
        }

        $data = [
            'transaction_amount' => $dados->transaction_amount,
            'payer' => [
                'email' => $dados->email,
                'identification' => [
                    'type' => 'CPF',
                    'number' => $dados->number
                ]
            ],
            'token' => $token,
            'installments' => $dados->installments,
        ];

    }

else {

    $data = [
        'transaction_amount' => 150.00,
        'payment_method_id' => 'pix',
        'payer' => [
            'email' => 'cliente@example.com'
        ],
        'description' => 'Compra na minha loja',
        'external_reference' => 'pedido_' . uniqid()
    ];
}

// Inicializa cURL
$ch = curl_init('https://api.mercadopago.com/v1/payments'); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $access_token",
    "Content-Type: application/json",
    "X-Idempotency-Key: ".uniqid()
]);

$response = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

curl_close($ch);

$result = json_decode($response, true);

if ($status >= 200 && $status < 300) {
    echo "<h2>Pagamento criado com sucesso!</h2>";
    
    if ($result['payment_method_id'] === 'pix') {
        echo "<p>Copie o código abaixo ou escaneie o QR Code:</p>";
        echo "<pre>" . htmlspecialchars($result['point_of_interaction']['transaction_data']['qr_code']) . "</pre>";
        echo "<img src='data:image/png;base64," . $result['point_of_interaction']['transaction_data']['qr_code_base64'] . "' />";
        var_dump($data);
    } else {
        echo "<p>Status do pagamento: " . $result['status'] . "</p>";
    }

} else {
    echo "<h2>Erro ao processar o pagamento</h2>";
    echo "<pre>" . print_r($result, true) . "</pre>";
}