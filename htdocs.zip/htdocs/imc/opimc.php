<?php

include('conexao.php');

if ($_POST) {

    $nome = $_POST['nome'];
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];

    $imc = $peso / ($altura ** 2);
    $imc = number_format($imc, 2);
    $descricaoImc = '';
    switch ($imc) {

        case $imc < 16:
            $descricaoImc = 'magreza grave';
            break;

        case  $imc >= 16 && $imc <= 16.9:
            $descricaoImc = 'magreza moderada';
            break;

        case  $imc >= 17 && $imc <= 18.5:
            $descricaoImc = 'magreza leve';
            break;

        case  $imc >= 18.6 && $imc <= 24.9:
            $descricaoImc = ' peso ideal';
            break;

        case  $imc >= 25 && $imc <= 29.9:
            $descricaoImc = 'sobrepeso';
            break;

        case  $imc >= 30 && $imc <= 34.9:
            $descricaoImc = 'obesidade grau I';
            break;

        case  $imc >= 35 && $imc <= 39.9:
            $descricaoImc = 'obesidade grau II ou severa';
            break;

        case  $imc >= 40:
            $descricaoImc = 'obesidade grau III ou mórbida';
            break;

        default:
            $descricaoImc = '';
            break;
    }
}

if (isset($_GET['acao'])) {


    if ($_GET['acao'] === 'cadastrar') {

        $query = 'insert into pessoa (nome, altura, peso, imc, descricao_imc) values (?, ?, ?, ?, ?)';
        $insert = $pdo->prepare($query);

        $insert->bindValue(1, $nome);
        $insert->bindValue(2, $altura);
        $insert->bindValue(3, $peso);
        $insert->bindValue(4, $imc);
        $insert->bindValue(5, $descricaoImc);
        $insert->execute();
    }

    if ($_GET['acao'] === 'editar') {

        $id = $_GET['id'];

        $query = 'update pessoa set nome = ?, altura = ?, peso = ? where id = ?';

        $update = $pdo->prepare($query);
        $update->bindValue(1, $nome);
        $update->bindValue(2, $altura);
        $update->bindValue(3, $peso);
        $update->bindValue(4, $id);
        $update->execute();
    }

    if ($_GET['acao'] === 'excluir') {

        $id = $_GET['id'];

        $query = 'delete from pessoa where id = ?';

        $delete = $pdo->prepare($query);
        $delete->bindValue(1, $id);
        $delete->execute();

    }

    header("Location: index.php");
}
