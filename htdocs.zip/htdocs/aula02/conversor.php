<?php
//Ler o valor em real e converter para dolar
$valor = 1;
$valorDolar = 5.60;
//Usando o 'number_format' passamos como parametro
//valor, quantidade de casas decimais, separador decimal, separador de milhar
$valorFinal = number_format($valor / $valorDolar, 2, ',', '.');


echo "Real para Dólar: U$ $valorFinal<br>";
$valorFinal = number_format($valorDolar * $valor, 2, ',', '.');
echo "Dólar para Real: R$ $valorFinal";

// '.' é usado para concatenar no php

echo '<br>Exemplo de '. 'concatenacao';

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            background: black;
            color: #fff;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }
    </style>
</head>
<body>

    

</body>
</html>