<!-- Sempre criar a sintaxe php -->
<?php

$salario = 3000;
$aluguel = 1200;
$contas = 600;
$mes = 'Maio';
$saldo = $salario - ($aluguel + $contas);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 02 - Introdução ao PHP</title>
    <style>
        body{
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            background: #f4f4f4;
            padding: 1.1rem;
        }
        .caixa{
            background: #fff;
            padding: 1.1rem;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    
        <div class="caixa">
            <h1>Resumo Financeiro de <?= $mes?></h1>
            <p><strong>Salário:</strong> R$ <?php echo $salario;?></p>
            <p><strong>Aluguel:</strong> R$ <?php echo $aluguel;?></p>   
            <p><strong>Contas:</strong> R$ <?php echo $contas;?></p>   
            <p><strong>Saldo:</strong> R$ <?php echo $saldo;?></p>
        </div>

</body>
</html>