<?php

// abaixo de 5 reprovado
// abaixo de 6 exame
// maior igual a 6 aprovado

$nota1 = 4;
$nota2 = 5;
$nota3 = 5;
$media = ($nota1 + $nota2 + $nota3) / 3;

if($media < 5){
    echo "<h1>Reprovado.<br></h1>";
}else if($media < 6){
    echo '<h1>Exame.<br></h1>';
}else{
    echo '<h1>Aprovado.<br></h1>';
}

echo "Sua média: $media";

?>