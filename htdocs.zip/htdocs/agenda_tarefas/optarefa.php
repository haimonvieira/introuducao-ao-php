<?php
include('conexao.php');


if ($_POST) {
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
}

if (isset($_GET['acao'])) {


    if ($_GET['acao'] === 'cadastrar') {

        $query = "insert into tarefas (titulo, descricao) values(?, ?)";
        $insert = $pdo->prepare($query);
        $insert->bindValue(1, $titulo);
        $insert->bindValue(2, $descricao);
        $insert->execute();
    }

    if ($_GET['acao'] === 'editar') {

        $id = $_GET['id'];

        $query = "update tarefas set titulo = ?, descricao = ? where id = ?";

        $update = $pdo->prepare($query);
        $update->bindValue(1, $titulo);
        $update->bindValue(2, $descricao);
        $update->bindValue(3, $id);
        $update->execute();
    }

    if ($_GET['acao'] === 'excluir') {

        $id = $_GET['id'];

        $query = "delete from tarefas where id = ?";
        $delete = $pdo->prepare($query);

        $delete->bindValue(1, $id);
        $delete->execute();
    }

    if ($_GET['acao'] === 'concluir') {

        date_default_timezone_set('America/Sao_Paulo');

        $id = $_GET['id'];
        $data = date('Y-m-d');
        $dataEHora = date('Y-m-d H:i:s');


        $query = "update tarefas set data_entrega = ?, status = ?, data_status_alterado = ? where id = ?";
        $update = $pdo->prepare($query);

        $update->bindValue(1, $data);
        $update->bindValue(2, 'concluida');
        $update->bindValue(3, $dataEHora);
        $update->bindValue(4, $id);

        $update->execute();
    }



    header("Location:index.php");
}
