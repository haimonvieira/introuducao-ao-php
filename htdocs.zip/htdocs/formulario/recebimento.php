<?php
//Aqui é tratado os dados que o formulário envia para o servidor

$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];

//Depois é enviado para o html e mostrar as informacoes

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recebimento</title>
    <style>
        body{
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 1rem;
            padding: 0 2rem;
        }
        a{
            text-decoration: none;
            border: 1px solid black;
            padding: .5rem;
            
        }
    </style>
</head>
<body>
    <h1>Recebimento do Formulário</h1>
    <hr>
    <p><strong>Nome: </strong><?= $nome?></p>
    <p><strong>E-mail: </strong><?= $email?></p>
    <p><strong>Telefone: </strong><?= $telefone?></p>
    <hr><br>
    <a href="index.php?msg=ok">Voltar</a>


</body>
</html>