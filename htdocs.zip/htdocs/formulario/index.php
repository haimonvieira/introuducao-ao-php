<?php

if(isset($_GET['msg']) && $_GET['msg'] == 'ok'){
    echo "<h2>Dados enviados com sucesso!</h2>";
}

?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário</title>
    <style>
        body{
            padding: 0 2rem;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 1rem;
        }
        input{
            all: unset;
            border: 1px solid #000;
            padding: .5rem;
        }
        input:focus{
            border: 2px solid black;
        }
        label{
            display: block;
            font-weight: 500;
            margin-top: 20px;
        }
        input[type="submit"]{
            display: block;
            margin-top: 20px;
            font-weight: 600;
            padding: .5rem 1rem;
            margin: 0 auto;
        }
    </style>
</head>
<body>

    <h1>Dados para Contato</h1>
    <!-- 'action' para onde vai as informacoes do formulario -->
    <!-- GET envia pela URL e o posto a informação é encapsulada -->
    <form action="recebimento.php" method="post">
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome">
        <label for="email">E-mail</label>
        <input type="email" name="email" id="email">
        <label for="telefone">Telefone</label>
        <input type="tel" name="telefone" id="telefone">
        <input type="submit" value="Enviar">
    </form>
    
</body>
</html>